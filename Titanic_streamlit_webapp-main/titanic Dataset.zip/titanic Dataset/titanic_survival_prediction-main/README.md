# titanic_survival_prediction
Getting Started with Kaggle Competation of titanic survival prediction
Gives an idea for:
      Data Loading
      Data preprocessing
      Story-telling
      Hyperparameter-tuning
      Normalization
      Pickling model
      Data cleaning
      Categorical-Encoding
      etc..
      
