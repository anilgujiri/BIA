# Titanic_streamlit_webapp

**`To Run Streamlit web-app` :**
  * On ***terminal*** type ``streamlit run [file.py]``
   * ex: In this case ``streamlit run titanic_strm.py``
